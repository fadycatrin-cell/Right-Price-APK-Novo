Right Price — versão 2.37

Esta versão mantém o layout profissional e os módulos existentes. Ajustes nesta auditoria:
- Corrigido o uso da janela financeira fixa: os cálculos, a tela de custos e o histórico ativo agora consultam as mesmas 12 chaves em config.periodKeys, sem avançar automaticamente a cada mês.
- O gesto de arrastar dentro do simulador não deve acionar a navegação por deslize entre abas.
- Versão identificada como 2.37.

Verificações automáticas realizadas:
- Sintaxe dos scripts JavaScript verificada com Node.js.
- Integridade do ZIP verificada.
- Teste matemático independente: exemplo de margem 20%, markup 2,857x, preço-base R$ 14,29 e delivery com acréscimo de 15% R$ 16,43.
- Teste de margem 100% com custos positivos deve ser marcado como inviável.

Limitação importante: não foi possível executar testes reais de interface em Android/navegador nem verificar persistência após instalação neste ambiente. Antes de usar para alterar preços reais, faça backup e confira 2–3 produtos conhecidos.
