RIGHT PRICE — BACKUP COM ESCOLHA DO LOCAL

O botão Exportar backup agora chama o plugin Android SaveFilePicker quando ele estiver presente. O plugin usa ACTION_CREATE_DOCUMENT (Storage Access Framework), exibindo o seletor do Android para o usuário escolher o local e o nome do arquivo.

IMPORTANTE PARA GERAR O APK:
O gerador Android precisa copiar vsprice/android-native/SaveFilePickerPlugin.java para android/app/src/main/java/br/com/vilasiria/formacaoprecos/SaveFilePickerPlugin.java e registrar a classe no MainActivity com registerPlugin(SaveFilePickerPlugin.class). Sem essa etapa, o APK não terá o seletor nativo e o botão avisará que é necessário atualizar o APK com o gerador compatível.

A lógica de restauração e os dados do aplicativo não foram alterados.
