package br.com.vilasiria.formacaoprecos;

import android.content.Intent;
import android.net.Uri;
import android.util.Base64;
import java.io.OutputStream;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "SaveFilePicker")
public class SaveFilePickerPlugin extends Plugin {
    private PluginCall pendingCall;
    private String pendingBase64;

    @PluginMethod
    public void saveFile(PluginCall call) {
        String filename = call.getString("filename", "Right_Price_Backup.json");
        String mimeType = call.getString("mimeType", "application/json");
        String data = call.getString("data");
        if (data == null || data.isEmpty()) {
            call.reject("Conteúdo do backup vazio.");
            return;
        }
        pendingCall = call;
        pendingBase64 = data;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mimeType);
        intent.putExtra(Intent.EXTRA_TITLE, filename);
        startActivityForResult(call, intent, "handleSaveFileResult");
    }

    @ActivityCallback
    private void handleSaveFileResult(PluginCall call, androidx.activity.result.ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != android.app.Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            JSObject cancelled = new JSObject();
            cancelled.put("cancelled", true);
            call.resolve(cancelled);
            pendingCall = null;
            pendingBase64 = null;
            return;
        }
        Uri uri = result.getData().getData();
        try (OutputStream output = getContext().getContentResolver().openOutputStream(uri, "w")) {
            if (output == null) throw new Exception("Não foi possível abrir o arquivo escolhido.");
            byte[] bytes = Base64.decode(pendingBase64, Base64.DEFAULT);
            output.write(bytes);
            output.flush();
            JSObject response = new JSObject();
            response.put("success", true);
            response.put("uri", uri.toString());
            call.resolve(response);
        } catch (Exception e) {
            call.reject("Falha ao salvar backup: " + e.getMessage(), e);
        } finally {
            pendingCall = null;
            pendingBase64 = null;
        }
    }
}
