Right Price
Versão 2.1

Aplicativo para formação de preços, custos e margens.
Inclui gás e produtos de limpeza nos custos operacionais.


V2.1.8 CORRECAO DO CAMPO DE ALIMENTOS
O campo 'ALIMENTOS E MATÉRIA-PRIMA CONSUMIDOS NO MÊS (R$)' aparece destacado logo após o faturamento em cada mês na aba Custos. Se ele não aparecer, o APK foi gerado com arquivos antigos. Gere o APK usando este ZIP e não reutilize uma pasta www/android antiga.
