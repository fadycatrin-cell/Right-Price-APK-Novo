RIGHT PRICE — PACOTE V2.1 PARA APK

Versão atual do aplicativo com:
- Gás e produtos de limpeza nos custos operacionais
- Backup local
- Proteção por PIN
- Navegação por gesto sem efeito de opacidade
- Ícone Right Price
- Interface revisada com textos mais objetivos e profissionais


CORREÇÃO V2.1.5:
- Corrigida a inicialização do idioma antes da criação dos meses.
- Corrige tela em branco na abertura do aplicativo.
- Mantidos conteúdo, cálculos, 5 idiomas e ícones do Right Price.


ATUALIZACAO DESTA ENTREGA
- Os arquivos icons/icon-*.png foram substituidos pelo icone verde com cifrao enviado pelo usuario.
- O botao Exportar backup agora tenta, nesta ordem: armazenamento nativo se o plugin estiver disponivel, compartilhamento de arquivo do Android/navegador e download JSON como alternativa.
- Restaurar backup continua aceitando arquivos .json exportados pelo aplicativo.
- Para o armazenamento nativo direto dentro de um APK Capacitor, o projeto Android precisa incluir e sincronizar @capacitor/filesystem. Sem esse plugin, o aplicativo usa compartilhamento ou download como alternativa.
- A assinatura original vila-siria-update.jks foi preservada. A senha nao e armazenada neste ZIP.
