Right Price
Versão 2.1

Aplicativo para formação de preços, custos e margens.
Inclui gás e produtos de limpeza nos custos operacionais.
