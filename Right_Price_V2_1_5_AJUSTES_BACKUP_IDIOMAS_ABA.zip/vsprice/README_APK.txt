RIGHT PRICE — PACOTE V2.1 PARA APK

Versão atual do aplicativo com:
- Gás e produtos de limpeza nos custos operacionais
- Backup local
- Proteção por PIN
- Navegação por gesto sem efeito de opacidade
- Ícone Right Price
- Interface revisada com textos mais objetivos e profissionais


CORREÇÃO V2.1.5:
- Corrigida a inicialização do idioma antes da criação dos meses.
- Corrige tela em branco na abertura do aplicativo.
- Mantidos conteúdo, cálculos, 5 idiomas e ícones do Right Price.
